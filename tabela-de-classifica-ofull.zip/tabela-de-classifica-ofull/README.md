# Tabela de Classificação - FULL

A Pen created on CodePen.io. Original URL: [https://codepen.io/rv-kel/pen/KKZpryy](https://codepen.io/rv-kel/pen/KKZpryy).

